﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.SkillStates.MrGreen
{
    class CloneThrow
    {
    }
}