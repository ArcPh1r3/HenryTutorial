﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Modules
{
    internal static class Helpers
    {
        internal const string agilePrefix = "<style=cIsUtility>Agile.</style> ";
    }
}